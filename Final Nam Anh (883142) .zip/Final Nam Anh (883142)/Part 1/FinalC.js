//getbuildingpermits.js
//load the json file from the city of calgary site
//search by jobcreated, tradename, address, licencetypes
//global  variables

var xhr = new XMLHttpRequest;//XMLHTTPRequest object
var parsedrecord;//parsed JSON file
//load pageSetup
window.onload=pageSetup;

function pageSetup() {
	
    //event listener
    document.getElementById("jobcreated").addEventListener("keyup", function (){ searchByjobcreated(this.value);},false);
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
     parsedrecord = JSON.parse(xhr.responseText);
      //displayData(r);
    }
  };
  xhr.open("GET", "https://data.calgary.ca/resource/vdjc-pybd.json ", true);
  xhr.send();
	
	
}
/*
*     "tradename": "CAREWELL PHARMACY",
        "address": "#104 580 ACADIA DR SE",
        "licencetypes": "RETAIL DEALER - PREMISES",
        "comdistnm": "ACADIA",
        "jobstatusdesc": "Renewal Licensed",
        "jobcreated": "2017-06-06T00:00:00.000",
        "longitude": "-114.04793605088301",
        "latitude": "50.964538384801145",
        "point": {
            "type": "Point",
            "coordinates": [
                -114.047936050883,
                50.964538384801
*/
function searchByjobcreated()
{
    //set up table
    var output="<tr><th>jobcreated</th><th>tradename</th><th>address</th><th>licencetypes</th> <th>Latitude</th><th>Longitude</th><th>Select</th></tr>";
    var jobcreated; 
    var tradename;
    var address;
    var licencetypes;
   
    var gmap;//creates hyperlink
    //modify bp to include
    var position="";//Use this to enter latitude and longitude and add this as a value to the Select radio button
    //begin search
    for(var i=0;i<parsedrecord.length;i++)
    {
        var record=parsedrecord[i];
            //check
            jobcreated=record.jobcreated;
            
            //assign
            if(jobcreated.startsWith(20))//partial match on string
            {
                output+="<tr><td>";
                output+=record.jobcreated;
                output+="</td><td>";
                output+=record.tradename;
                output+="</td><td>"
                output+=record.address;
                output+="</td><td>"
                output+=record.licencetypes;
                output+="</td><td>";
                output+=record.latitude;
                //add latitude to postition
                position=record.latitude;
                position+=","
                output+="</td><td>";
                output+=record.longitude;
                //add longitude to position
                position+=record.longitude;
                output+="</td><td>";
                
                //create hyperlink gmap
                gmap ="<a href=https://www.google.com/maps/search/?api=1&query="+position+" target=_blank>Click here to see map</a> ";
               
              
                output+=gmap;
                
                output+="</td></tr>";
            }
    }
    document.getElementById("searchresultsC").innerHTML=output;

}

