function Convert() {
  var startValue=document.getElementById("val_input").value;
   var typeOf=document.getElementById("Onhand").value;
    var typeto=document.getElementById("convertto").value;
    startValue=parseFloat(startValue);
    var endValue;

      if (isNaN(startValue)) 
      {
        var text="InvalId input"
        document.getElementById("val_output").innerHTML=endValue;

      }
      else{
        if(typeOf== "euro"){
          if(typeto=="us"){
            endValue=exchange(startValue, 1.04).toFixed(2);
            document.getElementById("val_output").innerHTML=endValue;}
          if(typeto=="canadian"){
            endValue=exchange(startValue, 1.34).toFixed(2);
            document.getElementById("val_output").innerHTML=endValue;}
          if(typeto=="bitcoin"){
            endValue=exchange(startValue, .000052).toFixed(2);
            document.getElementById("val_output").innerHTML=endValue;}
          if(typeto=="ether"){
            endValue=exchange(startValue, 0.00091).toFixed(2);
            document.getElementById("val_output").innerHTML=endValue;}
          
        }
        if(typeOf== "us"){
          if(typeto=="euro"){
            endValue=exchange(startValue, 0.96).toFixed(2);
            document.getElementById("val_output").innerHTML=endValue;}
          if(typeto=="canadian"){
            endValue=exchange(startValue, 1.28).toFixed(2);
            document.getElementById("val_output").innerHTML=endValue;}
          if(typeto=="bitcoin"){
            endValue=exchange(startValue, .000049).toFixed(2);
            document.getElementById("val_output").innerHTML=endValue;}
          if(typeto=="ether"){
            endValue=exchange(startValue, .00087).toFixed(2);
          document.getElementById("val_output").innerHTML=endValue;}
        }
        if(typeOf== "canadian"){
          if(typeto=="euro"){
            endValue=exchange(startValue, 0.75).toFixed(2);
            document.getElementById("val_output").innerHTML=endValue;}
          if(typeto=="us"){
            endValue=exchange(startValue, 0.78).toFixed(2);
            document.getElementById("val_output").innerHTML=endValue;}
          if(typeto=="bitcoin"){
            endValue=exchange(startValue, .000038).toFixed(2);
            document.getElementById("val_output").innerHTML=endValue;}
          if(typeto=="ether"){
            endValue=exchange(startValue, .00068).toFixed(2);
            document.getElementById("val_output").innerHTML=endValue;}
        }
        if(typeOf== "bitcoin"){
          if(typeto=="euro"){
            endValue=exchange(startValue, 19428.45).toFixed(2);
            document.getElementById("val_output").innerHTML=endValue;}
          if(typeto=="canadian"){
            endValue=exchange(startValue, 26045.08).toFixed(2);
            document.getElementById("val_output").innerHTML=endValue;}
          if(typeto=="us"){
            endValue=exchange(startValue, 20270.20).toFixed(2);
            document.getElementById("val_output").innerHTML=endValue;}
          if(typeto=="ether"){
            endValue=exchange(startValue, 17.61).toFixed(2);
            document.getElementById("val_output").innerHTML=endValue;}
        }
        if(typeOf== "ether"){
          if(typeto=="euro"){
            endValue=exchange(startValue, 1102.83).toFixed(2);
            document.getElementById("val_output").innerHTML=endValue;}
          if(typeto=="canadian"){
            endValue=exchange(startValue, 1478.54).toFixed(2);
            document.getElementById("val_output").innerHTML=endValue;}
          if(typeto=="us"){
            endValue=exchange(startValue, 1150.74).toFixed(2);
           document.getElementById("val_output").innerHTML=endValue;}
          if(typeto=="bitcoin"){
            endValue=exchange(startValue, .057).toFixed(2);
            document.getElementById("val_output").innerHTML=endValue;}
        }
      }
  function exchange (a,b){
  return a*b;
}
}
