function loadC(){
cradius=document.getElementById("cradius").value;
      cheight=document.getElementById("cheight").value;
      volume=Math.PI*cradius*cradius*cheight;
      price=volume*0.0012;
      text2="Flat bottomed cylinders<br>"+"Radius: "+cradius+"cm<br>Height: "+cheight+"cm<br>Volume: "+volume.toFixed(2)+"cm^3<br>Price: $"+price.toFixed(2);
      document.getElementById("result1").innerHTML = text2;  
      var order;
      order=resultmessage+ fname+" "+lname+"<br>"+address+"<br>"+code+"<br>"+phone+"<br>"+mail+"<br><br>Your Order:<br><br>";
      var resultmessage="Thank you for your order ";
      document.getElementById("displayapp1").innerHTML = order;
    }
    
   