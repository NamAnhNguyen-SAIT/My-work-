//getbuildingpermits.js
//load the json file from the city of calgary site
//search by permit number, address, range of building permit value
//global  variables

var xhr = new XMLHttpRequest;//XMLHTTPRequest object
var parsedrecord;//parsed JSON file
//load pageSetup
window.onload=pageSetup;

function pageSetup() {
	
    //event listener
    document.getElementById("id").addEventListener("keyup", function (){ searchByid(this.value);},false);
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
     parsedrecord = JSON.parse(xhr.responseText);
      //displayData(r);
    }
  };
  xhr.open("GET", "https://data.calgary.ca/resource/35ra-9556.json", true);
  xhr.send();
	
	
}
/*
*     "incident_info": " Southbound 52 Street and 61 Avenue SE ",
        "description": "Traffic incident. Blocking the left lane",
        "start_dt": "2022-12-12T12:11:18.000",
        "modified_dt": "2022-12-12T12:13:18.000",
        "quadrant": "SE",
        "longitude": "-113.95905579497824",
        "latitude": "50.99903906199427",
        "count": "1",
        "id": "2022-12-12T12:11:1850.99903906199427-113.95905579497824",
        "point": {
            "type": "Point",
            "coordinates": [
                -113.95905579497824,
                50.99903906199427
            ]
        },
        ":@computed_region_kxmf_bzkv": "159",
        ":@computed_region_4a3i_ccfj": "3",
        ":@computed_region_4b54_tmc4": "10"
*/
function searchByid()
{
    //set up table
    var output="<tr><th>ID</th><th>incident_info</th><th>description</th><th>Latitude</th><th>Longitude</th><th>Select</th></tr>";
    var id; 
    var incident_info;
    var description;
    var gmap;//creates hyperlink
    //modify bp to include
    var position="";//Use this to enter latitude and longitude and add this as a value to the Select radio button
    //begin search
    for(var i=0;i<parsedrecord.length;i++)
    {
        var record=parsedrecord[i];
            //check
            id=record.id;//assign
            if(id.startsWith(2022))//partial match on string
            {
                output+="<tr><td>";
                output+=record.id;
                output+="</td><td>";
                output+=record.incident_info;
                output+="</td><td>"
                output+=record.description;
                output+="</td><td>";
                output+=record.latitude;
                //add latitude to postition
                position=record.latitude;
                position+=","
                output+="</td><td>";
                output+=record.longitude;
                //add longitude to position
                position+=record.longitude;
                output+="</td><td>";
                
                //create hyperlink gmap
                gmap ="<a href=https://www.google.com/maps/search/?api=1&query="+position+" target=_blank>Click here to see map</a> ";
               
              
                output+=gmap;
                
                output+="</td></tr>";
            }
    }
    document.getElementById("searchresultsB").innerHTML=output;

}

