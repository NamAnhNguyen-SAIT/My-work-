// This part is for the AJAX shape
//spuare (1) (done) (show price and message)
function loadsquare() {
  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
      document.getElementById("displayapp").innerHTML = xhr.responseText;
    }
  };
  xhr.open("GET", "cubes.html", true);
  xhr.send();
}
//cylinder (2) (done) (show price and message)
function loadcylinder() {
  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
      document.getElementById("displayapp").innerHTML = xhr.responseText;
    }
  };
  xhr.open("GET", "Cylinders.html", true);
  xhr.send();
}
//Sper (3) 
function loadSpher() {
  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
      document.getElementById("displayapp").innerHTML = xhr.responseText;
    }
  };
  xhr.open("GET", "Spherical.html", true);
  xhr.send();
}
//cone (4)
function loadCone() {
  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
      document.getElementById("displayapp").innerHTML = xhr.responseText;
    }
  };
  xhr.open("GET", "Truncated.html", true);
  xhr.send();
}
var objectArray = [];
var i = 0;


//reviews the input fields and ensure that they are entered correctly. Will check if the fields are being added or updated and the correct function will be run
function validate(){

    //validate firstname
    var firstName = document.getElementById("firstname").value;
    var firstNameElement = document.getElementById("firstname");
    var firstNameTest = false;
    testString = /[a-zA-Z]/;
    if(testString.test(firstName)){
        firstNameTest = true;
        firstNameElement.style.borderTop = "darkgrey 1px solid";
        firstNameElement.style.borderLeft = "darkgrey 1px solid";
        firstNameElement.style.borderRight = "darkgrey 1px solid";
        firstNameElement.style.borderBottom = "black 2px solid";
    }
    else{
        firstNameElement.style.border = "red solid 2px";
    }

    //validate Lastname
    var lastName = document.getElementById("lastname").value;
    var lastNameElement = document.getElementById("lastname");
    var lastNameTest = false;
    testString = /[a-zA-Z]/;
    if(testString.test(lastName)){
        lastNameTest = true;
        lastNameElement.style.borderTop = "darkgrey 1px solid";
        lastNameElement.style.borderLeft = "darkgrey 1px solid";
        lastNameElement.style.borderRight = "darkgrey 1px solid";
        lastNameElement.style.borderBottom = "black 2px solid";
    }
    else{
        lastNameElement.style.border = "red solid 2px";
    }

    //validate address
    var streetAddress = document.getElementById("address").value;
    var streetAddressElement = document.getElementById("address");
    var streetAddressTest = false;
    testString = /[a-zA-Z]/;
    if(testString.test(streetAddress)){
        streetAddressTest = true;
        streetAddressElement.style.borderTop = "darkgrey 1px solid";
        streetAddressElement.style.borderLeft = "darkgrey 1px solid";
        streetAddressElement.style.borderRight = "darkgrey 1px solid";
        streetAddressElement.style.borderBottom = "black 2px solid";
    }
    else{
        streetAddressElement.style.border = "red solid 2px";
    }
    //validate postal field
    var postal = document.getElementById("postalcode").value;
    var postalElement = document.getElementById("postalcode");
    var postalTest = false;
    testString = /[ABCEGHJKLMNPRSTVXY][0-9][ABCEGHJKLMNPRSTVWXYZ][0-9][ABCEGHJKLMNPRSTVWXYZ][0-9]/;
    if(testString.test(postal)){
        postalTest = true;
        postalElement.style.borderTop = "darkgrey 1px solid";
        postalElement.style.borderLeft = "darkgrey 1px solid";
        postalElement.style.borderRight = "darkgrey 1px solid";
        postalElement.style.borderBottom = "black 2px solid";
    }
    else{
        postalElement.style.border = "red solid 2px";
    }
      //validate phone number field
      var phone = document.getElementById("phone").value;
      var phoneElement = document.getElementById("phone");
      var phoneTest = false;
      testString = /[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]/;
      if(testString.test(phone)){
          phoneTest = true;
          phoneElement.style.borderTop = "darkgrey 1px solid";
          phoneElement.style.borderLeft = "darkgrey 1px solid";
          phoneElement.style.borderRight = "darkgrey 1px solid";
          phoneElement.style.borderBottom = "black 2px solid";
      }
      else{
          phoneElement.style.border = "red solid 2px";
      }
   //validate email field
   var email = document.getElementById("email").value;
   var emailElement = document.getElementById("email");
   var testString = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
   var emailTest = false;
   if (testString.test(email)){
       emailTest = true;
       emailElement.style.borderTop = "darkgrey 1px solid";
       emailElement.style.borderLeft = "darkgrey 1px solid";
       emailElement.style.borderRight = "darkgrey 1px solid";
       emailElement.style.borderBottom = "black 2px solid";
   }
   else{
       emailElement.style.border = "red solid 2px";
   }
   var texttest;
   var texttest=firstName+" "+lastName+"<br>"+streetAddress+"<br>"+postal+"<br>"+phone+"<br>"+mail+"<br><br>Your Order:<br><br>";
   if(firstNameTest == true && lastNameTest == true && streetAddressTest == true   && postalTest == true && phoneTest == true && emailTest == true ){

    
      document.getElementById("displayList1").innerHTML = texttest;
    
}
else{
    alert("One or more fields are entered incorrectly");
}
}
    
