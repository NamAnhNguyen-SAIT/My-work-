var area;
var price;
function upload(){
    // messege when done
     var message="";
        var resultmessage="Thank you for your order ";
        var checkbox_value; //get value from check box value


    //document by ID (customer and cake)
    var lname = document.getElementById("lastname").value;
    var fname = document.getElementById("firstname").value;
    var address = document.getElementById("address").value;
    var phone = document.getElementById("phone").value;
    var code = document.getElementById("postalcode").value;
    var mail = document.getElementById("email").value;
    var type =document.getElementById("cakeType").value;
    var layer=document.getElementById("layers").value;
    var width=document.getElementById("cakewidth").value;
    var length=document.getElementById("cakelength").value;
    var radius=document.getElementById("cakeradius").value;
    //message end
    var text; 
    var text2;
    var text3;


    text=fname+" "+lname+"<br>"+address+"<br>"+code+"<br>"+phone+"<br>"+mail+"<br><br>Your Order:<br><br>";
    
    if(type=="sheetcake"){
        area = length*width;
        price=((area-900)*0.02+18)+((layer-1)*0.5*((area-900)*0.02+18));
       text3="sheetcake "+length+"cm x "+width+" cm with "+layer+" layers:<br>";
        text2= "$"+price.toFixed(2)+"<br>";
    }
    else{
        area = radius*radius*3.14;
        if(radius==15){
            price = 15+15*0.5*(layer-1);
            text3="Round cake 15cm with "+layer+" layers:<br>";
            text2= "$"+price.toFixed(2)+"<br>";
        }
        else{
            price=(area-707)*0.02+15+((area-707)*0.02+15)*0.5*(layer-1);
            text3="Round cake "+radius+"cm with "+layer+" layers:<br>";
            text2= "$"+price.toFixed(2)+"<br>";
        }
    
    }

    if(document.getElementById("extra1").checked==true){
        price+=5;
        text3 +="Cream Cheese icing<br>";
        text2 +="$5<br>";
        }
        if(document.getElementById("extra2").checked==true){
        price+=7;
        text3 +="Fruit and Almond topping<br>";
        text2 +="$7<br>";
        }
        if (document.getElementById("extra3").checked==true){
        price+=4;
        text3 +="Fruit Jam filling<br>";
        text2+="$4<br>";
        }

    price=price.toFixed(2);
    text3+= "Total:";
    text2+="$"+price;
    document.getElementById("result").innerHTML = text;
    document.getElementById("order").innerHTML = text3;
    document.getElementById("totalmoney").innerHTML = text2;
}

function change(){
    if(document.getElementById("cakeType").value=="sheetcake"){
        document.getElementById("sheetcake").style.display = "block";
        document.getElementById("round").style.display = "none";
    }
    else{
        document.getElementById("sheetcake").style.display = "none";
        document.getElementById("round").style.display = "block";
    }
}
