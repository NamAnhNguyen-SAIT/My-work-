function loadSP()
{ var shradius;
    var volume;
    var textspherical;
    var price;


    shradius=document.getElementById("sradius").value;   
    volume=0.5*(4/3*shradius*shradius*shradius*Math.PI);
    price=volume*0.0015;
    textspherical="½ Spherical<br>"+"radius: "+shradius+"cm<br>Volume: "+volume.toFixed(2)+"cm^3<br>Price: $"+price.toFixed(2);
    document.getElementById("displayspherical").innerHTML = textspherical;  
    var order;
    order=resultmessage+ fname+" "+lname+"<br>"+address+"<br>"+code+"<br>"+phone+"<br>"+mail+"<br><br>Your Order:<br><br>";
    var resultmessage="Thank you for your order ";
    document.getElementById("resultspherical").innerHTML = order;
      
  }
        
        