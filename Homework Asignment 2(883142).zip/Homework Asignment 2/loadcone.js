function loadCone() 
{   var volume;
    var Cradius1,Cradius2,Cheight;
    var textcone;
    var price;

    Cradius1=document.getElementById("coneradius1").value;
    Cradius2=document.getElementById("coneradius2").value;
    Cheight=document.getElementById("coneheight").value;
    volume=(1/3)*Math.PI*(Cradius1*Cradius1+Cradius1*Cradius2+Cradius2*Cradius2)*Cheight;
    price=volume*0.002;
    textcone="Truncated cone<br>"+"radius1: "+Cradius1+"cm<br>radius2:"+Cradius2+"cm<br>height: "+Cheight+"cm<br>Volume: "+volume.toFixed(2)+"cm^3<br>Price: $"+price.toFixed(2);


    document.getElementById("displaycone").innerHTML = textcone;  
}
//done (first time wrong: function name giong nhau)
// user input
