//This will load and parse the XML file that will allow it to be searched
var xhr=new XMLHttpRequest();
var xmldoc;//reference to parsed XML file
window.onload=loadXML;

function loadXML() {
	
	//create event listent
	document.getElementById("search").addEventListener("keyup", function (){ findLocation(this.value);},false);
	
	xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
      xmldoc = xhr.responseXML;
    }
  };
  xhr.open("GET", "welldata.xml", true);
  xhr.send();
	
}

/*
<location>
B1-14-21-W6
</location>
<welldepth>
3581.27
</welldepth>
<perfdepth>
2987.51
</perfdepth>
<perfzone>
10.0
</perfzone>
<stroke>
1.65
</stroke>
<strokepermin>
21
</strokepermin>
*/
function findLocation(location) {
	

var i;//iterator

var recordlocation;
//start table
var table="<tr><th>location</th><th> Welldepth</th><th>perfdepth </th><th> perfzone</th><th> stroke</th><th> strokepermin</th></tr>";
//process data by welldata
var x = xmldoc.getElementsByTagName("welldata");
  for (i = 0; i <x.length; i++) 
  { 
  //get location
  		recordlocation=x[i].getElementsByTagName("location")[0].childNodes[0].nodeValue;
		recordlocation = recordlocation.trim();
  //check if recordlocation starts with location 
  //even when start with location or without can't show up the info 
  			if (recordlocation.startsWith(location)) {
  	
    			table += "<tr><td>" +
    			x[i].getElementsByTagName("location")[0].childNodes[0].nodeValue +
   			 "</td><td>" +
    			x[i].getElementsByTagName("welldepth")[0].childNodes[0].nodeValue +
    			"</td><td>" +
   			 x[i].getElementsByTagName("perfdepth")[0].childNodes[0].nodeValue +
    			"</td><td>" +
				x[i].getElementsByTagName("perfzone")[0].childNodes[0].nodeValue +
    			"</td><td>" +
				x[i].getElementsByTagName("stroke")[0].childNodes[0].nodeValue +
    			"</td><td>" +
    			x[i].getElementsByTagName("strokepermin")[0].childNodes[0].nodeValue +
    			"</td></tr>";
    		}
  }
  
  document.getElementById("searchpart3").innerHTML = table;

}

/*<productiondata>
<location>
B1-14-21-W6
</location>
<date>
2004-06-04
</date>
<oilproduction>
66.53
</oilproduction>
<waterproduction>
379.23
</waterproduction>
<gasproduction>
17.08
</gasproduction>
</productiondata>
<productiondata>
*/