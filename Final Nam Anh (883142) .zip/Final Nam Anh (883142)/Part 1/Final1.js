//getbuildingpermits.js
//load the json file from the city of calgary site
//search by permit number, address, range of building permit value
//global  variables

var xhr = new XMLHttpRequest;//XMLHTTPRequest object
var parsedrecord;//parsed JSON file
//load pageSetup
window.onload=pageSetup;

function pageSetup() {
	
    //event listener
    document.getElementById("buildingpermit").addEventListener("keyup", function (){ searchByPermitId(this.value);},false);
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
     parsedrecord = JSON.parse(xhr.responseText);
      //displayData(r);
    }
  };
  xhr.open("GET", "https://data.calgary.ca/resource/c2es-76ed.json", true);
  xhr.send();
	
	
}
/*
*     "permitnum": "BP2022-18276",
"statuscurrent": "Pre Backfill Phase",
"applieddate": "2022-10-31T00:00:00.000",
"issueddate": "2022-11-15T00:00:00.000",
"permittype": "Single Construction Permit",
"permittypemapped": "Building",
"permitclass": "1106 - Single Family House",
"permitclassgroup": "Single Family",
"permitclassmapped": "Residential",
"workclass": "New",
"workclassgroup": "New",
"workclassmapped": "New",
"description": "SFD,GARAGE,DECK,PORCH,",
"applicantname": "MATTAMY HOMES CALGARY",
"contractorname": "MATTAMY (NORTHPOINT)",
"housingunits": "1",
"estprojectcost": "252605.29",
"totalsqft": "1539",
"originaladdress": "69 CITYLINE SQ NE",
"communitycode": "CSC",
"communityname": "CITYSCAPE"
*/
function searchByPermitId(bp)
{
    //set up table
    var output="<tr><th>Permit Number</th><th>Address</th><th>Latitude</th><th>Longitude</th><th>Value</th><th>Select</th></tr>";
    var permitnum; 
    var communityname;
    var gmap;//creates hyperlink
    //modify bp to include
    var position="";//Use this to enter latitude and longitude and add this as a value to the Select radio button
    //begin search
    for(var i=0;i<parsedrecord.length;i++)
    {
        var record=parsedrecord[i];
            //check
            permitnum=record.permitnum;//assign
            if(permitnum.startsWith(bp))//partial match on string
            {
                output+="<tr><td>";
                output+=record.permitnum;
                output+="<tr><td>";
                output+=record.communityname;
                
                output+="</td><td>"
                output+=record.originaladdress;
                output+="</td><td>";
                output+=record.latitude;
                //add latitude to postition
                position=record.latitude;
                position+=","
                output+="</td><td>";
                output+=record.longitude;
                //add longitude to position
                position+=record.longitude;
                output+="</td><td>";
                output+=record.estprojectcost;
                output+="</td><td>";
                //create hyperlink gmap
                gmap ="<a href=https://www.google.com/maps/search/?api=1&query="+position+" target=_blank>Click here to see map</a> ";
               
              
                output+=gmap;
                
                output+="</td></tr>";
            }
    }
    document.getElementById("searchresults").innerHTML=output;

}

