

//java script to process and display files
function getFinalQuiz() { 
	var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
      processXML(xhr);
    }
  };
  xhr.open("GET", "FinalQuiz.xml", true); 
  xhr.send();
	
}

function processXML(xhr) { //should I change this (undone)

    var i;
    //get data as xml file
    var xmldoc = xhr.responseXML;
    //start table
    var table=""; //change to list? or delete this (undone)
    //process data by record
    var x = xmldoc.getElementsByTagName("question"); //change this to 'question' (done)
      for (i = 0; i <x.length; i++) { 
        table += "<tr><td>" +
            x[i].getElementsByTagName("qnumber")[0].childNodes[0].nodeValue + ") "+// change to a,b,c ?? or change to question 1, 2 ,3??
            x[i].getElementsByTagName("qtitle")[0].childNodes[0].nodeValue +// change to a,b,c ?? or change to question 1, 2 ,3??
          "<br><input type=radio name=answer>" +
            x[i].getElementsByTagName("a")[0].childNodes[0].nodeValue +// change to a,b,c ?? or change to question 1, 2 ,3??
            "<br><input type=radio name=answer>" +
            x[i].getElementsByTagName("b")[0].childNodes[0].nodeValue +
            "<br><input type=radio name=answer>" +
            x[i].getElementsByTagName("c")[0].childNodes[0].nodeValue +
           "<br><input type=radio name=answer>" +
            x[i].getElementsByTagName("d")[0].childNodes[0].nodeValue +

        "</td></tr>";
      }
      
      document.getElementById("showquiz").innerHTML = table; //change this (done)
    
    }
    function getGradeQuiz() {
      var useranswer = document.getElementsByName('answer');
        
      for(i = 0; i < ele.length; i++) {
          if(ele[i].checked)
          document.getElementById("grade").innerHTML
                  = "answer: "+ele[i].value;
      }
  }
   
    
     