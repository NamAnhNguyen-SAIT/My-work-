function loadS() 
{   var volume;
    var length,height,width;
    var text;
    var price;
    
length=document.getElementById("length").value;
    height=document.getElementById("height").value;
    width=document.getElementById("width").value;
    volume=length*width*height;
    price=volume*0.001;
    text="Square/Rectangular Cubes<br>"+"Length: "+length+"cm<br>Width: "+width+"cm<br>Height: "+height+"cm<br>Volume: "+volume.toFixed(2)+"cm^3<br>Price: $"+price.toFixed(2);
    document.getElementById("result").innerHTML = text;  
}
//done (first time wrong: function name giong nhau)
// user input
