//getbuildingpermits.js
//load the json file from the city of calgary site
//search by unique_key, address, comm_name, roll_year
//global  variables

var xhr = new XMLHttpRequest;//XMLHTTPRequest object
var parsedrecord;//parsed JSON file
//load pageSetup
window.onload=pageSetup;

function pageSetup() {
	
    //event listener
    document.getElementById("unique_key").addEventListener("keyup", function (){ searchByunique_key(this.value);},false);
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
     parsedrecord = JSON.parse(xhr.responseText);
      //displayData(r);
    }
  };
  xhr.open("GET", "https://data.calgary.ca/resource/6zp6-pxei.json ", true);
  xhr.send();
	
	
}
/*
*      {
        "roll_year": "2017",
        "roll_number": "070027800",
        "address": "1930 MAYNARD RD SE",
        "assessed_value": "26180000",
        "assessment_class": "NR",
        "assessment_class_description": "Non-residential",
        "comm_code": "MLI",
        "comm_name": "MAYLAND",
        "latitude": "51.04784225611974",
        "longitude": "-114.00981065031557",
        "unique_key": "2017070027800",
        "year_of_construction": "1965",
        "land_use_designation": "I-G",
        "property_type": "LI",
        "land_size_sm": "28350.8",
        "land_size_sf": "305175",
        "land_size_ac": "7.01",
        "sub_property_use": "CS1835",
        "point": {
            "type": "Point",
            "coordinates": [
                -114.009810650316,
                51.04784225612
            ]
*/
function searchByunique_key()
{
    //set up table
    var output="<tr><th>jobcreated</th><th>address</th><th>comm_name</th><th>roll_year</th> <th>Latitude</th><th>Longitude</th><th>Select</th></tr>";
    var unique_key; 
    var address;
    var comm_name;
    var roll_year;
   
    var gmap;//creates hyperlink
    //modify bp to include
    var position="";//Use this to enter latitude and longitude and add this as a value to the Select radio button
    //begin search
    for(var i=0;i<parsedrecord.length;i++)
    {
        var record=parsedrecord[i];
            //check
            unique_key=record.unique_key;
            
            //assign
            if(unique_key.startsWith(20))//partial match on string
            {
                output+="<tr><td>";
                output+=record.unique_key;
                output+="</td><td>";
                output+=record.address;
                output+="</td><td>"
                output+=record.comm_name;
                output+="</td><td>"
                output+=record.roll_year;
                output+="</td><td>";
                output+=record.latitude;
                //add latitude to postition
                position=record.latitude;
                position+=","
                output+="</td><td>";
                output+=record.longitude;
                //add longitude to position
                position+=record.longitude;
                output+="</td><td>";
                
                //create hyperlink gmap
                gmap ="<a href=https://www.google.com/maps/search/?api=1&query="+position+" target=_blank>Click here to see map</a> ";
               
              
                output+=gmap;
                
                output+="</td></tr>";
            }
    }
    document.getElementById("searchresultsD").innerHTML=output;

}

